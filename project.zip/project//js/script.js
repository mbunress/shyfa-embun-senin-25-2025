
    document.getElementById("Afdhal").addEventListener('submit', function(event) {
        event.preventDefault(); //Mencegah form untuk submit secara default
    
        //Mendapatkan nilai username dan password
        var username = document.getElementById('username').value;
        var password = document.getElementById('password').value;
        var errormessage = document.getElementById('error-message');
     
        //Validasi Username dan password
        if (username === '' || password === '') {
            errormessage.textContent = 'isi goblok';
        } else if (username !== 'Afdhal' || password !=='12345') {
            errormessage.textContent = 'username atau password salah';
        } else {
            errormessage.textContent = ''
            alert('LOGIN SUKSES BRO!!');
        }
    });